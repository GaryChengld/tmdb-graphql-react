export default {
  useNextVariants: true,
  fontSize: 12,
  fontFamily: ['Montserrat', 'sans-serif', 'Helvetica Neue', 'Arial'].join(','),
};
