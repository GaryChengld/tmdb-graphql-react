export { default as NavBar } from './NavBar';
export { default as Footer } from './Footer';
export { default as Loading } from './Loading';
export { default as MovieCards } from './MovieCards';
export { default as MovieCard } from './MovieCard';
