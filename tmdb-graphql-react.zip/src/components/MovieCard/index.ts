export { default } from './MovieCard';
