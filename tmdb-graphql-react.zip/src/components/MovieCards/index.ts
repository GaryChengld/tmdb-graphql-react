export { default } from './MovieCards';
